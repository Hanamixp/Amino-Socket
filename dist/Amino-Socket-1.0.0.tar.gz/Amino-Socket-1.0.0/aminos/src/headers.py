headers = None


class Headers:
    def __init__(self):
        if headers:
            self.headers = headers
