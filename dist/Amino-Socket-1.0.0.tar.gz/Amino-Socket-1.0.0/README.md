[
![pypi](https://img.shields.io/badge/Amino_Sockets-Docs-orange)
](https://https://amino-socket.readthedocs.io/)
[
![pypi](https://img.shields.io/badge/Amino--Socket%20build%20and%20test-passing-brightgreen?logo=github&labelColor=black)
](https://github.com/Hanamixp/Amino-Socket)
[
![pypi](https://img.shields.io/badge/pypi-v1.0.0-blue)
](https://pypi.org/project/Amino-Socket/)

### Amino-Socket 
Amino-Socket is an Amino client for Python. It provides to access [aminoapps](https://aminoapps.com) WebSockets.
### Installation
You can use either `python3 setup.py install` or `pip3 install Amino-Socket` to install.
- **Note** This Python Module tested on `python3.10`
### Documentation
This project's documentation can be found at [![pypi](https://img.shields.io/badge/Amino_Sockets-Docs-orange)](https://https://amino-socket.readthedocs.io/)
